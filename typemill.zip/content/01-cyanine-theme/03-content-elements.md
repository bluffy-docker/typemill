# Content Elements

Cyanine provides a lot of other settings for your content area. For example: 

* Add an edit-button for github, gitlab or other plattforms.
* Show the author.
* Show the publish date.
* Show the chapter numbers in the navigation.

The Cyanine theme supports all content elements like tables, images, notices or downloads. It also supports anchor-links next to headlines, so you can deep link to certain content sections of your page. You can activate the anchors in the system settings of Typemill.