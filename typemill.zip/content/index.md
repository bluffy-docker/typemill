# Typemill

The open-source flat-file cms for text-driven websites. Create handbooks, documentations, manuals, web-novels, traditional websites, and more.

![youtube-video](media/live/youtube-6i2-uv88gke.jpeg "click to load video"){#6i2-uv88gke .youtube}

