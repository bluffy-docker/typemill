<?php

require __DIR__  . '/system/vendor/autoload.php';

require __DIR__  . '/system/system.php';

$app->run();