/*   Y O U R   J A V A S C R I P T

** Add your JavaScript here
** You can activate and use VUE.js and AXIOS: https://typemill.net/theme-developers/helper-functions#activate-vuejs-and-axios
** Typemillutilities.js is included in index.twig for managing youtube-videos.

*/