<?php

namespace Typemill\Events;

use Symfony\Component\EventDispatcher\Event;

/**
 * Event for the folder structure.
 */
 
class OnPluginsLoaded extends BaseEvent
{

}