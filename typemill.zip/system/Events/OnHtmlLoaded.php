<?php

namespace Typemill\Events;

use Symfony\Component\EventDispatcher\Event;

/**
 * Event for html page.
 */

class OnHtmlLoaded extends BaseEvent
{

}