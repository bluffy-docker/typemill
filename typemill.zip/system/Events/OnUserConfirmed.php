<?php

namespace Typemill\Events;

use Symfony\Component\EventDispatcher\Event;

/**
 * Event for the page tree.
 */
 
class OnUserConfirmed extends BaseEvent
{

}