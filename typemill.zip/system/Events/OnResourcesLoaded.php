<?php

namespace Typemill\Events;

use Symfony\Component\EventDispatcher\Event;

/**
 * Event for acl.
 */

class OnResourcesLoaded extends BaseEvent
{

}