<?php

namespace Typemill\Events;

use Symfony\Component\EventDispatcher\Event;

/**
 * Event for breadcrumb.
 */
 
class OnSessionSegmentsLoaded extends BaseEvent
{

}