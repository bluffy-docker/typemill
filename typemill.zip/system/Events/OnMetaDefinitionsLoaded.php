<?php

namespace Typemill\Events;

use Symfony\Component\EventDispatcher\Event;

/**
 * Event for markdown.
 */

class OnMetaDefinitionsLoaded extends BaseEvent
{

}