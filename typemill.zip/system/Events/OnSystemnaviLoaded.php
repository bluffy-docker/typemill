<?php

namespace Typemill\Events;

use Symfony\Component\EventDispatcher\Event;

/**
 * Event for settings
 */
 
class OnSystemnaviLoaded extends BaseEvent
{

}